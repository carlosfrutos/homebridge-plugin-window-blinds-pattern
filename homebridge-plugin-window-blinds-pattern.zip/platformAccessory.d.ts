import { PlatformAccessory, CharacteristicValue } from 'homebridge';
import { WindowBlindsPatternHomebridgePlatform } from './platform.js';
/**
 * Platform Accessory
 * An instance of this class is created for each accessory your platform registers
 * Each accessory may expose multiple services of different service types.
 */
export declare class WindowBlindsPatternPlatformAccessory {
    private readonly platform;
    private readonly accessory;
    private readonly service;
    private readonly name;
    private readonly debug;
    private readonly model;
    private readonly manufacturer;
    private readonly outputValueMultiplier;
    private readonly urlSetTargetPosition;
    private readonly urlGetCurrentPosition;
    private readonly statusPattern;
    private readonly matchingGroup;
    private readonly serial;
    private readonly timeout;
    private readonly minOpen;
    private readonly maxOpen;
    private currentPosition;
    private targetPosition;
    private positionState;
    constructor(platform: WindowBlindsPatternHomebridgePlatform, accessory: PlatformAccessory);
    /**
     * Handle requests to get the accessory name
     */
    getName(): Promise<CharacteristicValue>;
    /**
     * Handle requests to get the current value of the "Current Position" characteristic
     */
    getCurrentPosition(): Promise<CharacteristicValue>;
    /**
     * Handle requests to get the current value of the "Target Position" characteristic
     */
    getTargetPosition(): Promise<CharacteristicValue>;
    /**
     * Handle requests to set the "Target Position" characteristic
     */
    setTargetPosition(value: CharacteristicValue): Promise<void>;
    /**
     * Handle requests to get the current value of the "Position State" characteristic
     */
    getPositionState(): Promise<CharacteristicValue>;
}
