import { PLATFORM_NAME } from './settings.js';
import { WindowBlindsPatternHomebridgePlatform } from './platform.js';
/**
 * This method registers the platform with Homebridge
 */
export default (api) => {
    api.registerPlatform(PLATFORM_NAME, WindowBlindsPatternHomebridgePlatform);
};
//# sourceMappingURL=index.js.map